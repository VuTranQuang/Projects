//
//  ViewController.swift
//  ChildMath
//
//  Created by RTC-HN154 on 9/18/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // mảng Button để set kết quả lựa chọn ngẫu nhiên
    @IBOutlet var colectionSelect: [UIButton]!
    
    
    
    @IBOutlet weak var resultRight: UILabel!
    @IBOutlet weak var resultWrong: UILabel!
    @IBOutlet weak var timesCountdown: UILabel!
    
    // giá trị trong vùng bảng
    @IBOutlet weak var numbOnBoard1: UILabel!
    @IBOutlet weak var numbOnBoard2: UILabel!
    @IBOutlet weak var resultOnBoard: UILabel!
    
    @IBOutlet weak var dauCong: UILabel!
    @IBOutlet weak var dauBang: UILabel!
    
    
    
    // các button chọn kết quả
    @IBOutlet weak var selection1: UIButton!
    @IBOutlet weak var selection2: UIButton!
    @IBOutlet weak var selection3: UIButton!
    
    
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    
    var scoreWrong = 0
    var scoreRight = 0
    var time = 0
    var timer: Timer?
    override func viewDidLoad() {
        super.viewDidLoad()
        totalLabel.isHidden = true
    }
    
    
    // set time khi bắt đầu
    func start() {
        time = 10
        // MARK: chú ý: cần set giá trị của thời gian về nil trước khi chạy lại lần tiếp theo
        if timer != nil {
            timer?.invalidate()
            timer = nil
        }
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.countDown), userInfo: nil, repeats: true)
    }
    
    // Các phép toán ngẫu nhiên trên bảng
    func randomNumber() {
     
        let random1 = Int(arc4random_uniform(50) + 1)
        let random2 = Int(arc4random_uniform(50) + 1)
        numbOnBoard1.text = String(random1)
        numbOnBoard2.text = String(random2)
        setResult(numberA: random1, numberB: random2)
    }
    // CountDown
    @objc  func countDown() {
        setHiddenOfScore()
        if time > 0 {
            time -= 1
        }
        timesCountdown.text = String(time)
        if time <= 0 {
            totalLabel.text = "Score \(String(describing: resultRight.text!))"
            startButton.isHidden = false
            colectionSelect.forEach { item in
                item.setTitle("0", for: .normal)
            }
        } else {
            startButton.isHidden = true
        }
    }
    
    func setResult(numberA: Int, numberB: Int) {
        let random = Int(arc4random_uniform(50) + 2)
        colectionSelect.randomElement()?.setTitle(String(sum(p1: numberA, p2: numberB)), for: .normal)
        colectionSelect.randomElement()?.setTitle(String(random), for: .application)

        }
    
    
    // ẩn hiện các label theo logic
    func setHiddenOfScore() {
        if time <= 0 {
            numbOnBoard1.isHidden = true
            numbOnBoard2.isHidden = true
            resultOnBoard.isHidden = true
            dauCong.isHidden = true
            dauBang.isHidden = true
            totalLabel.isHidden = false
            
            
            
            selection1.isEnabled = false
            selection2.isEnabled = false
            selection3.isEnabled = false
        } else {
            numbOnBoard1.isHidden = false
            numbOnBoard2.isHidden = false
            resultOnBoard.isHidden = false
            dauCong.isHidden = false
            dauBang.isHidden = false
            totalLabel.isHidden = true
            
            selection1.isEnabled = true
            selection2.isEnabled = true
            selection3.isEnabled = true
        }
    }
    
    func sum(p1: Int, p2: Int) -> Int {
        return p1 + p2
    }
    
    func sumResult(p1: Int, p2: Int) -> String {
        return String(p1 + p2)
    }
    
//     Set các giá trị ngẫu nhiên để lựa chọn
        func randomPosition() {
            let randomPos = arc4random_uniform(18) + 1
            let random = Int(arc4random_uniform(18) + 19)
            let random1 = Int(arc4random_uniform(18) + 38)
            selection1.setTitle(String(random1), for: UIControl.State())
            selection2.setTitle(String(randomPos), for: UIControl.State())
            selection3.setTitle(String(random), for: UIControl.State())
        }
    
    @IBAction func onClickStart(_ sender: UIButton) {
        // MARK: Các func cần được gọi lần lượt theo thứ tự thực hiện đúng.
        start()
        randomPosition()
        randomNumber()
    }
    
    @IBAction func onClickSelection1(_ sender: UIButton) {
       
        if (sender.titleLabel?.text) == sumResult(p1: Int((numbOnBoard1?.text)!)!, p2: Int(numbOnBoard2.text!)!) {
            scoreRight += 1
            resultRight.text = String(scoreRight)
            time += 4
            randomNumber()
        } else {
            scoreWrong += 1
            resultWrong.text = String(scoreWrong)
            time -= 4
            randomNumber()
        }
        
    }
    
    
}

