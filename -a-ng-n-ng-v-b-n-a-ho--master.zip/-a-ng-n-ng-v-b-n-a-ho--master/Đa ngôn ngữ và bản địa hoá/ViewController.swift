//
//  ViewController.swift
//  Đa ngôn ngữ và bản địa hoá
//
//  Created by VuTQ10 on 11/18/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var labName: UILabel!
    
    @IBOutlet weak var labDate: UILabel!
    
    @IBOutlet weak var labAddress: UILabel!
    
    @IBOutlet weak var labMarried: UILabel!
    
    @IBOutlet weak var labNote: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    func multipleLaguage(_ language: String) {
        Localization.sharedInstance.setPreferred(preferred: language)
        labName.text = localize("Katarina")
        labDate.text = localize("20-8-1996")
        labAddress.text = localize("Thanh Xuân - Hà Nội")
        labMarried.text = localize("Độc thân")
        labNote.placeholder = localize("Write here!!!")
    }
    
    
    @IBAction func changeLanguage(_ sender: UIBarButtonItem) {
        multipleLaguage(sender.title!)
    }
    
}

