//
//  Localizable.swift
//  Đa ngôn ngữ và bản địa hoá
//
//  Created by VuTQ10 on 11/19/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import Foundation
public func localize(_ key: String) -> String {
    return Localization.sharedInstance.localizedStringForKey(key: key)
}

class Localization: NSObject {
    static let sharedInstance = Localization()
    
    var preferredBunle: Bundle!
    var preferredLanguage: String!
    
    func localizedStringForKey(key: String) -> String {
        var result: String!
        if preferredBunle != nil {
            result = self.preferredBunle.localizedString(forKey: key, value: nil, table: nil)
        }
        if result == nil {
            result = key
        }
        return result
    }
    
    func setPreferred(preferred: String) {
        self.preferredLanguage = preferred
        let bundlePath: NSString = Bundle.main.path(forResource: "Localizable", ofType: "strings", inDirectory: nil, forLocalization: preferred)! as NSString
        self.preferredBunle = Bundle.init(path: bundlePath.deletingLastPathComponent)
    }
}
