//
//  ViewController.swift
//  DigitalClock
//
//  Created by RTC-HN154 on 9/17/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelTimes: UILabel!
    @IBOutlet weak var LabelAmPm: UILabel!
    
    var timer: Timer?
    override func viewDidLoad() {
        super.viewDidLoad()
        updateClock()
        timer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(updateClock), userInfo: nil, repeats: true)
    }
    @objc
    func updateClock() {
        let date = Date()
        let calendar = Calendar.current
        let requestedComponents: NSCalendar.Unit = [
        NSCalendar.Unit.hour,
        NSCalendar.Unit.minute
        ]
        let components = (calendar as NSCalendar).components(requestedComponents, from: date)
        var hour = components.hour
        let minutes = components.minute
        if hour! > 12 {
            hour = hour! - 12
            LabelAmPm.text = "PM"
        } else {
            LabelAmPm.text = "AM"
        }
        labelTimes.text = padZero(hour!) + ":" + padZero(minutes!)
    }
    
    func padZero(_ num: Int) -> String {
        let temp = (num < 10 ? "0":"") + String(num)
        return temp
    }


}

