//
//  ViewController.swift
//  String <=> PlayList
//
//  Created by VuTQ10 on 11/19/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var keys = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
       let fileName = "Property List"
        keys = ["imageheader", "helpname", "numofpage"]
//        convertPlistToString(fileName: fileName as NSString)
        convertStringsToPlist(fileName: fileName)
    }
    
    func convertPlistToString(fileName: NSString) {
        guard let path = Bundle.main.path(forResource: fileName as String, ofType: "plist") else {
            return
        }
        guard let array = NSArray(contentsOfFile: path) else {
            return
        }
        var content = ""
        for dict in array {
            for key in (dict as AnyObject).allKeys {
                //lây ra giá trị vào thêm vào xâu ký tự để sau nay có thể ghi ra file strings
                if let subArray = (dict as AnyObject).value(forKey: key as! String) as? NSArray {
                    content = content + "--\(key)\n"
                    for value in subArray {
                        content = content + "+\(value)\n"
                    }
                }
                else
                {
                    if let value =  (dict as AnyObject).value(forKey: key as! String) {
                        content = content + "--\(key)\n+\(value)\n"
                    }
                }
            }
            content = content + "\n------\n"
            
            let newPath = "/Users/vutq10/Desktop/\(fileName).strings"
            do {
                try content.write(toFile: newPath, atomically: false, encoding: String.Encoding.utf8)
            } catch let error as NSError{
                print("Error:" + error.localizedDescription)
            }
        }
    }
    
//    func convertStringsToPlist(fileName: NSString) {
//        let nsstringPath = "/Users/vutq10/Desktop/\(fileName).strings"
//
//        guard let nsstringContent = try? NSString(contentsOfFile: nsstringPath as String, encoding: String.Encoding.utf8.rawValue) as String else  { return }
//
//        let array = nsstringContent.components(separatedBy: "\n-------\n")
//        var arrayPlist = [NSMutableDictionary]()
//
//        for value in array {
//            let dictdata = NSMutableDictionary()
//            let dictData = NSMutableDictionary()
//            //kiểm tra chắc chắn cái dòng chúng ta đọc != rỗng
//            if value.characters.count > 1{
//                //Lấy ra mỗi dictionary con
//                let aDict = value.components(separatedBy: "\n")
//                var key = ""
//                var valuesArray = [String]()
//                var content = ""
//                func addContentOfKey()
//                {
//                    let value = valuesArray.last
//                    valuesArray.removeLast()
//                    valuesArray.append(value! + "\n" + content)
//                    content = ""
//                }
//                for data in aDict {
//                    if (data == "") {
//                        continue
//                    }
//                    //Nếu mà là dấu "--" có nghĩa là key và "+" có nghĩa là value
//                    if (NSString(string: data).substring(with: NSRange(location: 0, length: 2)) == "--") {
//                        if (content != "") {
//                            addContentOfKey()
//                        }
//                        let index = data.characters.index(data.startIndex, offsetBy: 2)
//                        if (valuesArray.count > 0) {
//                            if valuesArray.count == 1 {
//                                dictData.setValue(valuesArray.first!, forKey: key)
//                            } else {
//                                dictData.setValue(valuesArray, forKey: key)
//                            }
//                            valuesArray = [String]()
//                        }
//                        key = data.substring(from: index)
//                    }
//                    else if (data.characters.first == "+") {
//                        let index = data.index(data.startIndex, offsetBy: 1)
//                        if (content != "") {
//                            addContentOfKey()
//                        }
//                        valuesArray.append(data.substring(from: index))
//                    } else {
//                        content = content != "" ? content + "\n" + data : data
//                    }
//                }
//                if (content != "") {
//                    addContentOfKey()
//                }
//                if (key.characters.count > 1 && valuesArray.count > 0) {
//                    if valuesArray.count == 1 {
//                        dictData.setValue(valuesArray.first!, forKey: key)
//                    }
//                    else
//                    {
//                        dictData.setValue(valuesArray, forKey: key)
//                    }
//                    valuesArray = [String]()
//                }
//                arrayPlist.append(dictData)
//            }
//        }
//        let arrayToWrite = NSArray(array: arrayPlist)
//        ///Users/dangcan/Desktop/\(fileName).plist is the path after the .strings file convert completely with name is (fileName).plist
//        //            let newPath = fileName.deletingPathExtension + ".plist"
//        arrayToWrite.write(toFile: "/Users/vutq10/Desktop/\(fileName).plist", atomically: true)
//    }
    
    func convertStringsToPlist(fileName: String)
    {
        let nsstringPath = "/Users/vutq10/Desktop/\(fileName).strings"
        
        //lấy dữ liệu từ .strings file
        guard let nsstringContent = try? NSString(contentsOfFile: nsstringPath, encoding: String.Encoding.utf8.rawValue)
            else
        {
            return
        }
        //Tách ra các phần tử để convert ngược lại
        let array = nsstringContent.components(separatedBy: "\n-------\n")
        var arrayPlist = [NSMutableDictionary]();
        
        /*Duyệt mỗi phần tử để ghép lại thành 1 dictionary sau đó thêm vào
         dictionary tổng để ghi ra .plist file
         */
        for value in array
        {
            let dictData = NSMutableDictionary()
            //kiểm tra chắc chắn cái dòng chúng ta đọc != rỗng
            if value.characters.count > 1{
                //Lấy ra mỗi dictionary con
                let aDict = value.components(separatedBy: "\n")
                var key = ""
                var valuesArray = [String]()
                for data in aDict
                {
                    //Nếu mà là dấu "-" có nghĩa là key và "+" có nghĩa là value
                    if (data.characters.first == "-") {
                        let index = data.index(data.startIndex, offsetBy: 1)
                        if (valuesArray.count > 0) {
                            if valuesArray.count == 1 {
                                print("key:\(key)\nvalue:\(valuesArray.first!)\n")
                                dictData.setValue(valuesArray.first!, forKey: key)
                            }
                            else
                            {
                                print("key:\(key)\nvalue:\(valuesArray)\n")
                                dictData.setValue(valuesArray, forKey: key)
                            }
                            valuesArray = [String]()
                        }
                        key = data.substring(from: index)
                    }
                    if (data.characters.first == "+") {
                        let index = data.index(data.startIndex, offsetBy: 1)
                        valuesArray.append(data.substring(from: index))
                    }
                }
                if (key.characters.count > 1 && valuesArray.count > 0) {
                    if valuesArray.count == 1 {
                        print("key:\(key)\nvalue:\(valuesArray.first!)\n")
                        dictData.setValue(valuesArray.first!, forKey: key)
                    }
                    else
                    {
                        print("key:\(key)\nvalue:\(valuesArray)\n")
                        dictData.setValue(valuesArray, forKey: key)
                    }
                    valuesArray = [String]()
                }
                print("\n")
                arrayPlist.append(dictData)
            }
            
        }
        let arrayToWrite = NSArray(array: arrayPlist)
        ///Users/dangcan/Desktop/\(fileName).plist is the path after the .strings file convert completely with name is (fileName).plist
        arrayToWrite.write(toFile: "/Users/vutq10/Desktop/\(fileName).plist", atomically: true)
    }

}

