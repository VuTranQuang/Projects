//
//  ViewController1.swift
//  PopoverDemo
//
//  Created by RTC-HN154 on 9/23/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickStatus(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            print("Like")
        case 2:
            print("Love")
        default:
            print("haha")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
