//
//  ViewController.swift
//  PopoverDemo
//
//  Created by RTC-HN154 on 9/23/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showView" {
            let vc = segue.destination as! ViewController1
            vc.popoverPresentationController?.delegate = self
            vc.preferredContentSize = CGSize(width: 230, height: 30)
        }
    }

}

extension ViewController: UIPopoverPresentationControllerDelegate {
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return .none
    }
}
