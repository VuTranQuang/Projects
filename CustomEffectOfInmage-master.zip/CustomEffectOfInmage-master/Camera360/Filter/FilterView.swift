//
//  FilterView.swift
//  Camera360
//
//  Created by VuTQ10 on 11/15/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import UIKit
class FilterView: UIViewController, ParameterAdjustmentDelegate {
  
    
    @IBOutlet weak var imgFilterView: ViewFilter!
    @IBOutlet weak var subView: UIView!
    
    var kSliderHeight: CGFloat = 37
    var kSliderMarginY: CGFloat = 2
    var add = false
    var nameFilter: String?
    var image: UIImage?
    var filter: CIFilter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imgFilterView.image = image
        let ciImage = CIImage(image: imgFilterView.image!)
        filter.setValue(ciImage, forKey: kCIInputImageKey)
    }
    
    override func viewDidLayoutSubviews() {
        if !add {
            add = true
            let arrPara = filterParaDiscriptions()
            let heightSlider = (self.subView.frame.height - kSliderMarginY * CGFloat(arrPara.count)) / CGFloat(arrPara.count)
            var yOffSet: CGFloat = 0
            for obj in arrPara {
                let view = CustomView(frame: CGRect(x: 0, y: self.subView.frame.origin.y + yOffSet + kSliderMarginY, width: self.view.frame.width, height: heightSlider), parameter: obj)
                
                view.parameter = obj
                view.delegate = self
                yOffSet += kSliderMarginY + heightSlider
                
                self.view.addSubview(view)
            }
        }
    }
    
    func filterParaDiscriptions() -> [ObjectPara] {
        var arrPara = [ObjectPara]()
        for inputName in filter.inputKeys {
            if inputName != "inputImage" {
                let attributes = filter.attributes
                let attribute = attributes[inputName] as! [String: AnyObject]
                let minValue = attribute[kCIAttributeSliderMin] as! Float
                let maxValue = attribute[kCIAttributeSliderMax] as! Float
                let defaultValue = attribute[kCIAttributeDefault] as! Float
                arrPara.append(ObjectPara(name: inputName, key: inputName, minimumValue: minValue, maximumValue: maxValue, currentValue: defaultValue))
            }
        }
        return arrPara
    }
    
    func parameterValueDidChange(param: ObjectPara) {
        filter.setValue(param.currentValue, forKey: param.key!)
        let ciTemp = imgFilterView.getImageFilter(filter: filter)
        imgFilterView.image = ciTemp
    }
    
    @IBAction func saveImage(_ sender: UIBarButtonItem) {
        UIImageWriteToSavedPhotosAlbum(imgFilterView.image!, self, nil, nil)
    }
    
    
    
    
}
