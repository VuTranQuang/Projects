//
//  ViewFilter.swift
//  Camera360
//
//  Created by VuTQ10 on 11/13/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import UIKit


class ViewFilter: UIImageView {
    var imageFilter: UIImage?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func getImageFilter(filter: CIFilter) -> UIImage {
        let outputImage = filter.outputImage
        let ciContext = CIContext()
        let ouptImageRef = ciContext.createCGImage(outputImage!, from: outputImage!.extent)
        let uiImage = UIImage(cgImage: ouptImageRef!)
        return uiImage
    }
}

