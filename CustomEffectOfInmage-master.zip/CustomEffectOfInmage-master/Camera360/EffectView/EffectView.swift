//
//  EffectView.swift
//  Camera360
//
//  Created by VuTQ10 on 11/13/19.
//  Copyright © 2019 VuTQ10. All rights reserved.
//

import UIKit
let kSampleImageName = "sample"
class EffectView: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet weak var imgView: ViewFilter!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var filters = [CIFilter]()
    var defaultImgs = [UIImage]()
    var imageEffect = UIImage()
    let filterDescriptions: [(filterName: String, filterDisplayName: String)] =
        [
            ("CIColorControls", "None"),
            ("CIPhotoEffectMono", "Mono"),
            ("CIPhotoEffectTonal", "Tonal"),
            ("CIPhotoEffectNoir", "Noir"),
            ("CIPhotoEffectFade", "Fade"),
            ("CIPhotoEffectChrome", "Chrome"),
            ("CIPhotoEffectProcess", "Process"),
            ("CIPhotoEffectTransfer", "Transfer"),
            ("CIPhotoEffectInstant", "Instant"),
            ("CIColorControls", "Cl Controls"),
            ("CIColorPosterize", "Cl Posterize"),
            ("CIExposureAdjust", "Exposure Adjust"),
            ("CIGammaAdjust", "Gamma Adjust")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for desctiption in filterDescriptions {
            filters.append(CIFilter(name: desctiption.filterName) ?? CIFilter())
            if let img = UIImage(named: desctiption.filterDisplayName) {
                defaultImgs.append(img)
            }
        }
        imageEffect = UIImage(named: kSampleImageName)!
        imgView.image = imageEffect
    }
    
    @IBAction func saveImage(_ sender: UIBarButtonItem) {
        UIImageWriteToSavedPhotosAlbum(imgView.image!, self, nil, nil)
    }
    
    @IBAction func openAlbum(_ sender: UIBarButtonItem) {
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.sourceType = .photoLibrary
        self.present(imgPicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickerImage: UIImage = (info[.originalImage]) as? UIImage
        {
            imgView.image = pickerImage
            imageEffect = pickerImage
        }
        self.dismiss(animated: true, completion: nil)
    }
    
}
extension EffectView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filterDescriptions.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! PhotoEffectCollectionCell
        if indexPath.item < 9 {
            cell.filterImageView.image = defaultImgs[indexPath.item]
        } else {
            cell.filterImageView.image = UIImage(named: "filter.png")
        }
        cell.filterImageView.contentMode = .scaleAspectFill
        cell.filter = filters[indexPath.item]
        cell.filterNameLabel.text = filterDescriptions[indexPath.item].filterDisplayName
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.item < 9 {
            let tempCIImage = CIImage(image: imageEffect)
            filters[indexPath.item].setValue(tempCIImage, forKey: kCIInputImageKey)
            let uiTemp = imgView.getImageFilter(filter: filters[indexPath.item])
            imgView.image = uiTemp
            
        } else {
            let mapViewController = self.storyboard?.instantiateViewController(withIdentifier: "FilterView") as? FilterView
            mapViewController?.filter = filters[indexPath.item]
            mapViewController?.image = imgView.image
            self.navigationController?.pushViewController(mapViewController!, animated: true)
        }
    }
    
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        return 10
//    }
}
