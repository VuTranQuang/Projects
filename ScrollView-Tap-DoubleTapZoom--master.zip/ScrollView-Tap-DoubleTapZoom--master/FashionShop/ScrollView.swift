//
//  ScrollView.swift
//  FashionShop
//
//  Created by RTC-HN154 on 10/3/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ScrollView: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageController: UIPageControl!
    
    var photo = [UIImageView]()
    var pageImages = [String]()
    var frontScrollViews: [UIScrollView] = []
    var firs = false
    override func viewDidLoad() {
        super.viewDidLoad()
        pageImages = ["shop1-0", "shop1-1", "shop1-2", "shop1-3"]
        pageController.currentPage = 0
        pageController.numberOfPages = pageImages.count
        scrollView.minimumZoomScale = 0.5
        scrollView.maximumZoomScale = 5
        
        
//        loadImage()
    }
    
    
    override func viewDidLayoutSubviews() {
        if !firs {
            firs = true
        let pagesScrollViewSize = scrollView.frame.size
        scrollView.contentSize = CGSize(width: pagesScrollViewSize.width * CGFloat(pageImages.count), height: 0)
        
        for i in 0..<pageImages.count {
            let imgView = UIImageView(image: UIImage(named: pageImages[i] + ".jpg"))
            // Dùng khi chỉ dùng 1 scroll không
//            imgView.frame = CGRect(x: CGFloat(i) * scrollView.frame.width, y: 0 , width: scrollView.frame.width, height: scrollView.frame.height)
            
                // Dùng khi sử dụng scroll lồng vào scroll
              imgView.frame = CGRect(x: 0, y: 0 , width: scrollView.frame.width, height: scrollView.frame.height)
            imgView.contentMode = .scaleAspectFit
         
                photo.append(imgView)
          
            let frontScrollView = UIScrollView(frame: CGRect(x: CGFloat(i) * scrollView.frame.width, y: 0 , width: scrollView.frame.width, height: scrollView.frame.height))
            frontScrollView.minimumZoomScale = 1
            frontScrollView.maximumZoomScale = 2
            frontScrollView.delegate = self
            frontScrollView.addSubview(imgView)
           frontScrollViews.append(frontScrollView)
            
            
            // MARK: zoomIn and Out khi Tap and DoubleTap
            frontScrollView.isUserInteractionEnabled = true
            frontScrollView.isMultipleTouchEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(tapImg(gesture:)))
            tap.numberOfTapsRequired = 1
            frontScrollView.addGestureRecognizer(tap)
            let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTabImg(gesture:)))
            doubleTap.numberOfTapsRequired = 2
            tap.require(toFail: doubleTap)  // Mã này giúp App không bị mập mờ giữa việc tap và doubleTap. Tránh hiện tượng phóng to rồi mới thu nhỏ khi ta doubleTap
            frontScrollView.addGestureRecognizer(doubleTap)
            
            self.scrollView.addSubview(frontScrollView)
        }
        }
    }
    
    
    @IBAction func onClickPage(_ sender: UIPageControl) {
        scrollView.contentOffset = CGPoint(x: CGFloat(pageController.currentPage) * scrollView.frame.width, y: 0)
    }
    
    
//
//    func loadImage() {
//        for i in 0..<pageImages.count {
//        let imgView = UIImageView(image: UIImage(named: pageImages[i] + ".jpg"))
////        let imgView = UIImageView(image: UIImage(named: "sleepGirl"))
////        imgView.frame = CGRect(x: 0, y: 0, width: imgView.frame.size.width, height: imgView.frame.size.height)
//
//
//
//        // MARK: zoomIn and Out khi Tap and DoubleTap
//        imgView.isUserInteractionEnabled = true
//        imgView.isMultipleTouchEnabled = true
//        let tap = UITapGestureRecognizer(target: self, action: #selector(tapImg(gesture:)))
//        tap.numberOfTapsRequired = 1
//        imgView.addGestureRecognizer(tap)
//        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTabImg(gesture:)))
//        doubleTap.numberOfTapsRequired = 2
//        tap.require(toFail: doubleTap)  // Mã này giúp App không bị mập mờ giữa việc tap và doubleTap. Tránh hiện tượng phóng to rồi mới thu nhỏ khi ta doubleTap
//        imgView.addGestureRecognizer(doubleTap)
//
//
//
////        // Setup for Image
////        imgView.contentMode = .scaleAspectFit
////        photo = imgView
////        scrollView.contentSize = CGSize(width: imgView.bounds.width, height: imgView.bounds.height)
////        scrollView.minimumZoomScale = 0.5
////        scrollView.maximumZoomScale = 5
//
//        self.scrollView.addSubview(imgView)
//        }
//    }

//   @objc func tapImg(gesture: UITapGestureRecognizer) {
//        let position = gesture.location(in: photo[pageController.currentPage])
//        zoomRectForscale(Scale: scrollView.zoomScale * 1.5, center: position)
//    }
    @objc func tapImg(gesture: UITapGestureRecognizer) {
        let position = gesture.location(in: frontScrollViews[pageController.currentPage])
        zoomRectForscale(Scale: scrollView.zoomScale * 1.5, center: position)
    }

  @objc func doubleTabImg(gesture: UITapGestureRecognizer) {
    let position = gesture.location(in: frontScrollViews[pageController.currentPage])
        zoomRectForscale(Scale: scrollView.zoomScale * 0.5, center: position)
    }

    func zoomRectForscale(Scale: CGFloat, center: CGPoint) {
        var zoomRect = CGRect()

        // Lấy CGRect
        let scrollViewSize = scrollView.bounds.size
        zoomRect.size.height = scrollViewSize.height / Scale
        zoomRect.size.width = scrollViewSize.width / Scale

        // Lấy CGPoint
        zoomRect.origin.x = center.x - (zoomRect.size.width / 2)
        zoomRect.origin.y = center.y - (zoomRect.size.height / 2)
        frontScrollViews[pageController.currentPage].zoom(to: zoomRect, animated: true)
    }

    // Zoom
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return photo[pageController.currentPage]
    }
}
