//
//  ViewController.swift
//  Calculator
//
//  Created by RTC-HN154 on 9/30/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputTextfield: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    var isTappingNumber = false
    var isEndOperation = true
    var firtNumber: Double = 0
    var secondNumber: Double = 0
    var opration = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        inputTextfield.isUserInteractionEnabled = false
        resultLabel.text = "0"
    }
    
    
    @IBAction func numberAction(_ sender: UIButton) {
        let number = sender.currentTitle
        if isTappingNumber {
            inputTextfield.text = inputTextfield.text! + number!
        } else {
            inputTextfield.text = number
            isTappingNumber = true
        }
    }
    

    @IBAction func operatorsAction(_ sender: UIButton) {
        opration = sender.currentTitle!
        if let inputOperation = Double(inputTextfield.text!) {
            if isEndOperation {
                firtNumber = inputOperation
                isEndOperation = false
            } else {
                firtNumber = Double(resultLabel.text!)!
                inputTextfield.text = "\(firtNumber)"
            }
        } else {
            print("404")
        }
        isTappingNumber = false
        if opration == "%" {
            equalAction(sender)
        } else if opration == "+/-" {
            equalAction(sender)
        }
    }
    
    @IBAction func equalAction(_ sender: UIButton) {
        isTappingNumber = false
        var result: Double = 0
        if let realSecondNumber = Double(inputTextfield.text!) {
            secondNumber = realSecondNumber
        }
        switch opration {
        case "+":
            result = firtNumber + secondNumber
        case "-":
            result = firtNumber - secondNumber
        case "*":
            result = firtNumber * secondNumber
        case "/":
            result = firtNumber / secondNumber
        case "%":
            result = firtNumber / 100
        case "+/-":
            if firtNumber < 0 {
                firtNumber = fabs(firtNumber)
                result = firtNumber
            } else {
                firtNumber = -1 * firtNumber
                result = firtNumber
            }
            inputTextfield.text = "\(result)"
        default:
            print("Error operation")
        }
        resultLabel.text = "\(result)"
    }
    
    @IBAction func acAction(_ sender: UIButton) {
        firtNumber = 0
        secondNumber = 0
        inputTextfield.text = ""
        resultLabel.text = "0"
        isEndOperation = true
    }
}

