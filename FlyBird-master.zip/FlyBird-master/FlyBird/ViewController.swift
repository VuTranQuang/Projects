//
//  ViewController.swift
//  FlyBird
//
//  Created by RTC-HN154 on 9/30/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var bird = UIImageView()
    var soundBird = AVAudioPlayer()
    var listSound = ["sound", "sound"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        drawBackground()
        addBirds()
        flyUpandDown()
        playSound()
    }
    
    
    func playSound() {
        let pathfile = Bundle.main.path(forResource: listSound[0], ofType: ".mp3")
        let url = URL(fileURLWithPath: pathfile!)
        soundBird =  try! AVAudioPlayer(contentsOf: url)
        soundBird.prepareToPlay()
        soundBird.play()
        soundBird.delegate = self
     
    }
    func drawBackground() {
        let background = UIImageView(image: UIImage(named: "background"))
        background.frame = self.view.bounds
        background.contentMode = .scaleAspectFill
        self.view.addSubview(background)
    }
    func addBirds() {
        bird = UIImageView(frame: CGRect(x: 100, y: 100, width: 110, height: 68))
        bird.animationImages = [UIImage(named: "1")!, UIImage(named: "2")!, UIImage(named: "3")!, UIImage(named: "4")!, UIImage(named: "5")!, UIImage(named: "6")!, UIImage(named: "7")!, UIImage(named: "8")!, UIImage(named: "9")!]
        bird.animationRepeatCount = 0
        bird.animationDuration = 1
        bird.startAnimating()
        self.bird.transform = self.bird.transform.scaledBy(x: 1, y: 1).concatenating(CGAffineTransform(rotationAngle: 45))
        self.view.addSubview(bird)
    }
    func flyUpandDown() {
        UIView.animate(withDuration: 4 , animations: {
            self.bird.center = CGPoint(x: self.view.bounds.width - 50, y: self.view.bounds.height - 50)
        }, completion: { finished in
            self.bird.transform = self.bird.transform.scaledBy(x: -1, y: 1).concatenating(CGAffineTransform(rotationAngle: 0))
            UIView.animate(withDuration: 4, animations: {
                self.bird.center = CGPoint(x: 50, y: 50)
            }, completion: { finished in
                self.bird.transform = self.bird.transform.scaledBy(x: -1, y: 1).concatenating(CGAffineTransform(rotationAngle: -45))
                
                UIView.animate(withDuration: 4, animations: {
                    self.bird.center = CGPoint(x: self.view.bounds.width - 50, y: 50)
                }, completion: { finished in
                    self.bird.transform = self.bird.transform.scaledBy(x: -1, y: 1).concatenating(CGAffineTransform(rotationAngle: -45))
                    
                    UIView.animate(withDuration: 4, animations: {
                        self.bird.center = CGPoint(x: 80, y: self.view.bounds.height - 50)
                    }, completion: { finished in
                        self.bird.transform = self.bird.transform.scaledBy(x: 1, y: 1).concatenating(CGAffineTransform(rotationAngle: 2.6))
                        UIView.animate(withDuration: 4, animations: {
                            self.bird.center = CGPoint(x: 75, y: 75)
                        }, completion: { finished in
                            self.bird.transform = self.bird.transform.scaledBy(x: -1, y: 1).concatenating(CGAffineTransform(rotationAngle: -1.6))
                        })
                    })
                })
            })
        })
        
    }
    
}
extension ViewController: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if flag {
            let pathfile = Bundle.main.path(forResource: listSound[1], ofType: ".mp3")
            let url = URL(fileURLWithPath: pathfile!)
            soundBird =  try! AVAudioPlayer(contentsOf: url)
            soundBird.prepareToPlay()
            soundBird.play()
        }
    }
}

