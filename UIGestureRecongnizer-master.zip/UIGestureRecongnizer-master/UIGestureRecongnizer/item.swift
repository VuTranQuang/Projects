//
//  item.swift
//  UIGestureRecongnizer
//
//  Created by RTC-HN154 on 10/1/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit
class Item: UIImageView, UIGestureRecognizerDelegate {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setup()
    }
    func setup() {
        self.isUserInteractionEnabled = true
        self.isMultipleTouchEnabled = true
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(onPan(panGesture:)))
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchPhoto(pinchGestureRecognizer:)))
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(rotateItem(rotateGestureRecognizer:)))
        
        rotateGesture.delegate = self
        self.addGestureRecognizer(rotateGesture)
        self.addGestureRecognizer(pinchGesture)
        self.addGestureRecognizer(panGesture)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    @objc func onPan(panGesture: UIPanGestureRecognizer) {
        if panGesture.state == .began  || panGesture.state == .changed {
            let point = panGesture.location(in: self.superview)
            self.center = point
        }
    }
    
  @objc  func pinchPhoto(pinchGestureRecognizer: UIPinchGestureRecognizer) {
        if let view = pinchGestureRecognizer.view {
            view.transform = view.transform.scaledBy(x: pinchGestureRecognizer.scale, y: pinchGestureRecognizer.scale)
            pinchGestureRecognizer.scale = 1
        }
    }
    
    @objc func rotateItem(rotateGestureRecognizer: UIRotationGestureRecognizer) {
        if let view = rotateGestureRecognizer.view {
            view.transform = view.transform.rotated(by: rotateGestureRecognizer.rotation)
            rotateGestureRecognizer.rotation = 0
        }
    }
}
