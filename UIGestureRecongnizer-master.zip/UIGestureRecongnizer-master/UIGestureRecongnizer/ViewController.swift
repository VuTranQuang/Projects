//
//  ViewController.swift
//  UIGestureRecongnizer
//
//  Created by RTC-HN154 on 10/1/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onTap(tapGesture:)))
        self.view.addGestureRecognizer(tapGesture)
    }
    @objc func onTap(tapGesture: UITapGestureRecognizer) {
        let point =  tapGesture.location(in: self.view)
        let snowFlake = UIImageView(image: UIImage(named: "snowflake"))
        snowFlake.bounds.size = CGSize(width: 40, height: 40)
        snowFlake.center = point
        self.view.addSubview(snowFlake)
    }
    


}

