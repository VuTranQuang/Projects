//
//  ViewController.swift
//  ZingMp3
//
//  Created by RTC-HN154 on 9/23/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageHV: UIImageView!
    @IBOutlet weak var nameText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageHV.alpha = 0
        nameText.alpha = 0
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIView.animate(withDuration: 4, animations:  {
            self.imageHV.alpha = 1
            }) { finish in
                UIView.animate(withDuration: 3, animations: {
                    self.nameText.center = CGPoint(x: self.imageHV.center.x, y: 100)
                    self.nameText.alpha = 1
                    })
        }
    }


}

