////
////  ViewController.swift
////  PushNotification
////
////  Created by VuTQ10 on 11/18/19.
////  Copyright © 2019 VuTQ10. All rights reserved.
////
//
//import UIKit
//import UserNotifications
//
//class ViewController: UIViewController {
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        if #available(iOS 10.0, *) {
//            let center = UNUserNotificationCenter.current()
//            center.requestAuthorization(options: [.badge, .alert, .sound]) { granted, error in }
//            center.delegate = self
//        } else {
//            
//        }
//    }
//    
//    func addNotification(with trigger: UNNotificationTrigger) {
//            let content = UNMutableNotificationContent()
//        content.title = NSString.localizedUserNotificationString(forKey: "Alan Walker", arguments: nil)
//        content.body = NSString.localizedUserNotificationString(forKey: "EDM Song", arguments: nil)
//        // Muốn có nhạc khi notification xuất hiện, nhạc phải có đuôi "aiff" và dưới 30s
//        content.sound = UNNotificationSound.init(named: UNNotificationSoundName(rawValue: "fade.aiff"))
//        // Khi có thông báo, sẽ hiển thị số thông báo chưa được đọc trên app
//        content.badge = NSNumber(integerLiteral: UIApplication.shared.applicationIconBadgeNumber + 1)
//        content.categoryIdentifier = "iOSSwift"
//        
//        if let path = Bundle.main.path(forResource: "kata", ofType: "jpg") {
//            let url = URL(fileURLWithPath: path)
//            do {
//                let attachment = try UNNotificationAttachment(identifier: "kata", url: url, options: nil)
//                content.attachments = [attachment]
//            } catch {
//                print("Can not load image")
//            }
//        }
//        let request = UNNotificationRequest.init(identifier: "FiveSecond", content: content, trigger: trigger)
//        // Add các thuộc tính vào hệ thống quản lý các notification của iOS
//        let center = UNUserNotificationCenter.current()
//        center.add(request)
//    }
//    
//
//    @IBAction func datePickerChange(_ sender: UIDatePicker) {
//        let calendar = Calendar(identifier: .gregorian)
//        let components = calendar.dateComponents(in: .current, from: sender.date)
//        let newComponents = DateComponents(calendar: calendar, timeZone: .current, month: components.month, day: components.day, hour: components.hour, minute: components.minute)
//        // Muốn notification này chạy repeats: true thì timeInterval phải >= 60s, nếu không sẽ báo lỗi
//        let trigger = UNCalendarNotificationTrigger(dateMatching: newComponents, repeats: false)
//        addNotification(with: trigger)
//    }
//    
//    @IBAction func triggerNotification(_ sender: UIButton) {
//        let trigger = UNTimeIntervalNotificationTrigger.init(timeInterval: 5, repeats: false)
//        addNotification(with: trigger)
//    }
//    
//    @IBAction func removeNotification(_ sender: UIButton) {
//        let center = UNUserNotificationCenter.current()
//        center.removeAllPendingNotificationRequests()
//    }
//    
//}
//
//extension ViewController: UNUserNotificationCenterDelegate {
//    
//    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
//        UIApplication.shared.applicationIconBadgeNumber = 0
//    }
//    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
//        print("???")
//    }
//}
//
