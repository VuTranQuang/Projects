//
//  ViewController.swift
//  DrawBall
//
//  Created by RTC-HN154 on 9/24/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //    @IBOutlet weak var textNumber: UITextField!
    
    static var ball = UIImageView()
    
    var n = 5
    var index = 4
    var margin: CGFloat = 40
    var marginY: CGFloat = 200
    
    var lastOnLed = -1
    var comeBack = -1
    var time = Timer()
    var viewn = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        time = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(runningLed), userInfo: nil, repeats: true)
        
        
        drawBall()
    }
    
    @objc func runningLed() {
        //    if lastOnLed != -1 {
        //        turnOffLed()
        //    }
        //    if lastOnLed == n - 1 {
        //
        //        lastOnLed -= 1
        //    } else {
        //        lastOnLed = lastOnLed + 1
        //
        //    }
        //
        //    turnOnLed()
        
        //    if lastOnLed != -1 {
        //        turnOffLed()
        //    }
        //    if lastOnLed == index && index != 0 {
        //        lastOnLed -= 1
        //        index -= 1
        //    } else {
        //        lastOnLed += 1
        //        index = n - 1
        //    }
        //    turnOnLed()
        //    }
        
        
        if lastOnLed != -1 {
            turnOffLed()
        }
        if lastOnLed == 22 {
            lastOnLed = -2
            index = n - 1
        }
        if lastOnLed == 31 {
            lastOnLed = lastOnLed - 11
        }
        if lastOnLed == 32 {
            lastOnLed = lastOnLed - 2
        }
        
        if lastOnLed == 33 {
            lastOnLed = lastOnLed - 2
            print(lastOnLed)
        }
        if lastOnLed == 23 {
            lastOnLed = lastOnLed + 9
            index  = index - 2
            print(lastOnLed)
        }
        if lastOnLed == 13 {
            lastOnLed = lastOnLed + 9
        }
        if lastOnLed == 20 && index == 31 {
            lastOnLed = lastOnLed - 11
            print(lastOnLed)
        }
        
        if lastOnLed == 30 && index == 31 {
            lastOnLed = lastOnLed - 11
        }
        var tent = 10
        
        
        if lastOnLed == index && index != 0 && tent == 10  {
            lastOnLed =  lastOnLed + 10
            index = index + 10
            print(lastOnLed)
            print(index)
            if lastOnLed > 44 {
                lastOnLed -= 11
                index -= 11
                tent = tent - 1
                print(tent)
                print(lastOnLed)
                print(index)
            }
        } else {
            lastOnLed += 1
            print(lastOnLed)
        }
        
        if lastOnLed == 39 && tent == 9 {
            lastOnLed =  lastOnLed - 9
            index = index - 8
            print("fuck \(lastOnLed)")
            print("fuck \(index)")
        }
        turnOnLed()
    }
    
    func turnOnLed() {
        if let ball = self.view.viewWithTag(100 + lastOnLed)  as? UIImageView {
            ball.image = UIImage(named: "redBall")
            //            print(ball.tag)
        }
    }
    
    func turnOffLed() {
        if let ball = self.view.viewWithTag(100 + lastOnLed)  as? UIImageView{
            ball.image = UIImage(named: "Grey")
            print(ball.tag)
        }
    }
    
    
    
    
    
    
    func drawBall() {
        //        self.view.subviews.forEach { (views) in
        //            if views.tag != 999 || views.tag != 998 {
        //                views.removeFromSuperview()
        //            }
        //
        //        }
        
        //        n = Int(textNumber.text ?? "") ?? 0
        
        for index in 0..<n {
            for indexCot in 0..<n {
                let image = UIImage(named: "redBall")
                ViewController.ball = UIImageView(image: image)
                
                ViewController.ball.center = CGPoint(x: margin + CGFloat(index) * spaceBetweemBall(), y:  marginY + CGFloat(indexCot) * spaceBetweemBallHeight())
                //                ViewController.ball.tag = index + 100
                ViewController.ball.tag = index*10 + indexCot + 100
                //                print(ViewController.ball.tag)
                self.view.addSubview(ViewController.ball)
                self.view.setNeedsDisplay()
            }
        }
    }
    
    
    func spaceBetweemBall() -> CGFloat {
        let space  = (self.view.bounds.width - 2*margin)/CGFloat(n - 1)
        return space
    }
    func spaceBetweemBallHeight() -> CGFloat {
        let space  = (self.view.bounds.height - 2*marginY)/CGFloat(n - 1)
        return space
    }
    
    //    @IBAction func onClickDraw(_ sender: UIButton) {
    //     
    //        drawBall()
    //    }
    
}

