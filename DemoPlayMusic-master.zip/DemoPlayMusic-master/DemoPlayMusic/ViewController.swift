//
//  ViewController.swift
//  DemoPlayMusic
//
//  Created by RTC-HN154 on 9/25/19.
//  Copyright © 2019 RTC-HN154. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer  // import cho phần lấy thông tin của bài hát

class ViewController: UIViewController {

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var startTime: UILabel!
    @IBOutlet weak var totalTime: UILabel!
    @IBOutlet weak var sliderDruration: UISlider!
    
    // Danh sách các bài hát
    var listMusic = ["Sakura", "hotaru", "modentaking"]
    
    var audio = AVAudioPlayer()
    var isPlaying = true
    var timer = Timer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: Nhạc vẫn sẽ chạy khi bạn quay lại background
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: .defaultToSpeaker)
        } catch {
            print("404")
        }
        
        
        // Load Song
        if let mp3String = Bundle.main.path(forResource: listMusic[0], ofType: ".mp3") {
            let url = URL(fileURLWithPath: mp3String)
            do {
                audio = try AVAudioPlayer(contentsOf: url, fileTypeHint: nil)
                audio.delegate = self
                
                
                // MARK: Lấy thông tin hiển thị của bài hát khi khoá màn hình. Test trên máy thật.
                // Starst
                guard let image = UIImage(named: "Sakura") else { return }
                let artwork = MPMediaItemArtwork.init(boundsSize: image.size, requestHandler: { size -> UIImage in
                    return image
                })
                MPNowPlayingInfoCenter.default().nowPlayingInfo = [MPMediaItemPropertyTitle: "Sakura",
                                                                   MPMediaItemPropertyArtist: "Anata",
                                                                   MPMediaItemPropertyPlaybackDuration: audio.duration,
                                                                   MPMediaItemPropertyArtwork: artwork]
                UIApplication.shared.beginReceivingRemoteControlEvents()
                becomeFirstResponder()
                
                // End
            } catch _ {
                return
            }
        }
        audio.currentTime = 0
        audio.prepareToPlay()
        sliderDruration.maximumValue = Float(audio.duration)
        totalTime.text = String(format: "%.02f", audio.duration/60)
    }
    override func remoteControlReceived(with event: UIEvent?) {
        if let event = event {
            if event.type == .remoteControl {
                switch event.subtype {
                case .remoteControlPlay:
                    audio.play()
                case .remoteControlPause:
                    audio.pause()
                case .remoteControlNextTrack:
                    print("bai tiep theo")
                case .remoteControlPreviousTrack:
                    print("bai truoc do")
                default:
                    print("chua thiet lap")
                }
            }
        }
    }
    
    // Mark: Update time follow song
   @objc func updateTimeLeft() {
    let minu: Int = Int(audio.currentTime / 60)
    let sec: Int = Int(audio.currentTime.truncatingRemainder(dividingBy: 60))
//    let sec = Int(audio.currentTime / 60)
    if (sec < 10 && minu < 10){
        self.startTime.text = "0\(minu):0\(sec) "
        
    }else{
        if sec < 10 {
            self.startTime.text = "\(minu):0\(sec) "
        } else if minu < 10 {
            self.startTime.text = "0\(minu):\(sec) "
        }else{
            self.startTime.text = "\(minu):\(sec) "
        }
    }
    sliderDruration.value = Float(audio.currentTime)
    }

    // Play and Pause
    @IBAction func actionPlay(_ sender: UIButton) {
        if isPlaying {
            audio.play()
        sender.isSelected = true
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimeLeft), userInfo: nil, repeats: true)
        } else {
            audio.pause()
            sender.isSelected = false
            timer.invalidate()
        }
        isPlaying = !isPlaying
    }
    
    // "+", "-" vollum
    @IBAction func sldVollum(_ sender: UISlider) {
        audio.volume = sender.value
    }
    
    @IBAction func sld_Timer(_ sender: UISlider) {
        audio.pause()
        let curTime = sliderDruration.value
        audio.currentTime = TimeInterval(curTime)
        audio.play()

    }
    
    @IBAction func repeatButton(_ sender: UISwitch) {
        if sender.isOn {
        }
    }
    
}



extension ViewController: AVAudioPlayerDelegate {
    
    // MARK: sau khi bản nhạc kết thúc sẽ chuyển sang bài tiếp theo.
     func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        
      
        if flag {
            if let mp3String = Bundle.main.path(forResource: listMusic[1], ofType: ".mp3") {
                let url = URL(fileURLWithPath: mp3String)
                do {
                    audio = try AVAudioPlayer(contentsOf: url, fileTypeHint: nil)
                    
                    
                    timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimeLeft), userInfo: nil, repeats: true)
                    audio.delegate = self
                    sliderDruration.maximumValue = Float(audio.duration)
                    audio.currentTime = 0
                    audio.prepareToPlay()
                    totalTime.text = String(format: "%2.2f", audio.duration/60)
                    audio.play()
                } catch _ {
                    return
                }
            }
        
        } else {
            if let mp3String = Bundle.main.path(forResource: listMusic[2], ofType: ".mp3") {
                let url = URL(fileURLWithPath: mp3String)
                do {
                    audio = try AVAudioPlayer(contentsOf: url, fileTypeHint: nil)
                    
                    
                    timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimeLeft), userInfo: nil, repeats: true)
                    audio.delegate = self
                    audio.currentTime = 0
                    audio.prepareToPlay()
                    sliderDruration.maximumValue = Float(audio.duration)
                    totalTime.text = String(format: "%2.2f", audio.duration/60)
                    audio.play()
                } catch _ {
                    return
                }
            }
        }
        }
}

